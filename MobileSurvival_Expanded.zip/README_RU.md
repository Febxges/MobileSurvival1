# MOBILE SURVIVAL — Unity starter (этап 1)

Это исходная основа мобильной survival-игры от первого лица с сервером до 20 игроков.
Это **не готовая копия Rust и не готовый APK**: здесь нет финальных 3D-моделей, анимаций,
звуков, карты и настроенного хостинга. Добавлены стартовые C#-системы, которые нужно
подключить в Unity и затем расширять.

## Рекомендуемая среда
- Unity 6 LTS (или Unity 2022.3 LTS с проверкой совместимости)
- Template: 3D (URP)
- Платформа клиента: Android
- Пакеты через Package Manager:
  - Netcode for GameObjects (`com.unity.netcode.gameobjects`)
  - Unity Transport (`com.unity.transport`)
- Для сетевого игрока добавьте `NetworkObject` и `NetworkTransform`.
- В проекте включите **Active Input Handling: Both** или **Input Manager (Old)**.

## Подключение
1. Создайте проект Unity 3D URP.
2. Скопируйте папку `Assets/MobileSurvival` в `Assets/` проекта.
3. Создайте сцену `Bootstrap`.
4. Создайте объект `NetworkManager`, добавьте `NetworkManager` и `UnityTransport`.
5. В NetworkManager укажите Player Prefab (см. ниже), включите scene management при необходимости.
6. На Player Prefab добавьте `NetworkObject`, `NetworkTransform`, `CharacterController`,
   `PlayerMotor`, `MobileInput`, `SurvivalStats`, `PlayerInventory`.
7. Добавьте Player Prefab в список Network Prefabs.
8. Создайте Canvas с экранными кнопками/джойстиком и назначьте ссылки в `MobileInput`.
9. Для локального теста запустите `NetworkManager.Singleton.StartHost()` из UI.
   Для выделенного сервера запустите `StartServer()` в server build.
10. Ограничение в 20 подключений задаётся в NetworkManager Inspector: `Max Connected Clients = 20`
    (в некоторых версиях поле называется `MaxConnections`).

## Важно о сети
Сервер должен быть авторитетным: клиент не должен сам решать, кому принадлежат ресурсы,
инвентарь, постройки или результаты боя. Этот starter оставляет движение на NetworkTransform
для прототипа. Перед публичным запуском перенесите проверки движения, сбора, крафта,
строительства и урона на сервер, добавьте античит, rate limits, reconnect и мониторинг.

## Первый тест
- Соберите Android-клиент.
- Запустите отдельную Server Build на ПК/VPS (Linux headless предпочтителен).
- Откройте UDP-порт, настроенный в UnityTransport (по умолчанию обычно 7777).
- Подключите два клиента к одному адресу через `UnityTransport.SetConnectionData(...)`.
- Не публикуйте сервер без настройки firewall, логирования и серверной валидации.

## Следующие этапы
1. Сбор ресурсов и предметы мира.
2. Слоты инвентаря, перенос и контейнеры.
3. Крафт и рецепты.
4. Строительство и сохранение построек.
5. Постоянное серверное сохранение мира/игроков в базе данных.
6. Мобильный HUD, переназначение и масштабирование кнопок.
7. Оптимизация: URP, LOD, occlusion culling, pooling, ограничение сетевых обновлений.

## Ограничения этой версии
Это каркас исходного кода, а не готовый продукт. Для APK нужны Unity Editor, Android Build Support,
сцена, префабы, модели, материалы, UI, тесты и серверная инфраструктура.
