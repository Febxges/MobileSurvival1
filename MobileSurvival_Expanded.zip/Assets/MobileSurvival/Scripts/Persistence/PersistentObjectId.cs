using UnityEngine;

public class PersistentObjectId : MonoBehaviour
{
    [SerializeField] private string id;
    [SerializeField] private string prefabKey;
    public string Id => id;
    public string PrefabKey => prefabKey;

#if UNITY_EDITOR
    private void OnValidate()
    {
        if (string.IsNullOrEmpty(id)) id = System.Guid.NewGuid().ToString("N");
    }
#endif
}
