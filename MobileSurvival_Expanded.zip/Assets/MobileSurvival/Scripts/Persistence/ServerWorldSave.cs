using System;
using System.IO;
using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Пример периодического серверного JSON-сохранения сетевых объектов с компонентом
/// PersistentObjectId. Это заготовка: восстановление объектов и игроковых данных
/// нужно реализовать под конкретную схему игры перед релизом.
/// </summary>
public class ServerWorldSave : MonoBehaviour
{
    [SerializeField, Min(15f)] private float saveIntervalSeconds = 60f;
    private float timer;
    private string SavePath => Path.Combine(Application.persistentDataPath, "world_save.json");

    [Serializable] private class WorldSnapshot { public int version = 1; public SavedObject[] objects; }
    [Serializable] private class SavedObject
    {
        public string id;
        public string prefabKey;
        public Vector3 position;
        public Quaternion rotation;
    }

    private void Update()
    {
        if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsServer) return;
        timer += Time.deltaTime;
        if (timer >= saveIntervalSeconds) { timer = 0f; SaveNow(); }
    }

    public void SaveNow()
    {
        if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsServer) return;

        var ids = FindObjectsByType<PersistentObjectId>(FindObjectsSortMode.None);
        var snapshot = new WorldSnapshot { objects = new SavedObject[ids.Length] };
        for (int i = 0; i < ids.Length; i++)
        {
            var t = ids[i].transform;
            snapshot.objects[i] = new SavedObject {
                id = ids[i].Id, prefabKey = ids[i].PrefabKey,
                position = t.position, rotation = t.rotation
            };
        }

        string json = JsonUtility.ToJson(snapshot, true);
        string temp = SavePath + ".tmp";
        File.WriteAllText(temp, json);
        if (File.Exists(SavePath)) File.Delete(SavePath);
        File.Move(temp, SavePath);
    }

    private void OnApplicationQuit() => SaveNow();
}
