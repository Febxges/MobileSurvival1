# Быстрая сборка Player Prefab

Иерархия:
- Player (NetworkObject, NetworkTransform, CharacterController, PlayerMotor,
  MobileInput, SurvivalStats, PlayerInventory)
  - CameraPivot (локальная позиция примерно Y=1.6)
    - Main Camera
  - BodyVisual (простая капсула/модель; отключайте рендер для локального игрока при необходимости)

На Canvas:
- Левая зона: джойстик (для первого прототипа можно подключить любой UI joystick и передавать
  его Vector2 в `MobileInput.SetMove`).
- Правая прозрачная панель: `TouchLookArea`, ссылка на MobileInput локального игрока.
- Кнопки: `TouchButton` с Jump / Sprint / Crouch.
- Отдельная кнопка взаимодействия вызывает соответствующий ServerRpc у объекта рядом.

Для сохранения данных пока нет постоянной БД. NetworkList живёт только в памяти сервера и
сбрасывается при перезапуске. Следующий обязательный этап — серверный persistence слой.
