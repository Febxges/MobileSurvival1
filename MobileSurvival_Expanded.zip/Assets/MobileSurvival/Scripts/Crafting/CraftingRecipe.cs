using System;
using UnityEngine;

[Serializable]
public struct RecipeIngredient
{
    public string itemId;
    [Min(1)] public int amount;
}

[CreateAssetMenu(menuName = "Mobile Survival/Crafting Recipe")]
public class CraftingRecipe : ScriptableObject
{
    public string recipeId;
    public string displayName;
    public RecipeIngredient[] ingredients;
    public string outputItemId;
    [Min(1)] public int outputAmount = 1;
    [Min(0f)] public float craftSeconds = 0f;
}
