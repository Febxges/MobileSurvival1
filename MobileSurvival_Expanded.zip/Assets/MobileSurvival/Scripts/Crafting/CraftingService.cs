using Unity.Netcode;
using UnityEngine;

/// <summary>Серверная проверка ресурсов для простого мгновенного крафта.</summary>
public class CraftingService : NetworkBehaviour
{
    [SerializeField] private CraftingRecipe[] recipes;

    [ServerRpc]
    public void CraftServerRpc(string recipeId, ServerRpcParams rpcParams = default)
    {
        if (!IsServer || string.IsNullOrWhiteSpace(recipeId)) return;

        CraftingRecipe recipe = null;
        foreach (var candidate in recipes)
            if (candidate != null && candidate.recipeId == recipeId) { recipe = candidate; break; }
        if (recipe == null) return;

        ulong sender = rpcParams.Receive.SenderClientId;
        if (!NetworkManager.ConnectedClients.TryGetValue(sender, out var client)) return;
        var inventory = client.PlayerObject != null ? client.PlayerObject.GetComponent<PlayerInventory>() : null;
        if (inventory == null || !inventory.HasItems(recipe.ingredients)) return;

        inventory.RemoveItems(recipe.ingredients);
        inventory.AddItems(recipe.outputItemId, recipe.outputAmount);
    }
}
