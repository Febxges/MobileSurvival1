using Unity.Netcode;
using UnityEngine;

/// <summary>Дополнительная проверка лимита. Основной лимит также выставьте в NetworkManager Inspector.</summary>
public class ServerConnectionLimit : MonoBehaviour
{
    [SerializeField, Range(1, 20)] private int maxPlayers = 20;

    private void OnEnable()
    {
        if (NetworkManager.Singleton != null)
            NetworkManager.Singleton.ConnectionApprovalCallback += Approval;
    }

    private void OnDisable()
    {
        if (NetworkManager.Singleton != null)
            NetworkManager.Singleton.ConnectionApprovalCallback -= Approval;
    }

    private void Approval(NetworkManager.ConnectionApprovalRequest request,
                          NetworkManager.ConnectionApprovalResponse response)
    {
        response.Approved = NetworkManager.Singleton.ConnectedClientsIds.Count < maxPlayers;
        response.CreatePlayerObject = response.Approved;
        response.Pending = false;
    }
}
