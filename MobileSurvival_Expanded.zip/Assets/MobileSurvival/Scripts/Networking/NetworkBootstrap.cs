using Unity.Netcode;
using UnityEngine;

/// <summary>Подключите методы к кнопкам меню: Host, Client, Dedicated Server.</summary>
public class NetworkBootstrap : MonoBehaviour
{
    [SerializeField] private string serverAddress = "127.0.0.1";
    [SerializeField] private ushort port = 7777;

    public void StartHost()
    {
        ConfigureTransport();
        NetworkManager.Singleton.StartHost();
    }

    public void StartClient()
    {
        ConfigureTransport();
        NetworkManager.Singleton.StartClient();
    }

    public void StartDedicatedServer()
    {
        ConfigureTransport();
        NetworkManager.Singleton.StartServer();
    }

    private void ConfigureTransport()
    {
        var transport = NetworkManager.Singleton.GetComponent<Unity.Netcode.Transports.UTP.UnityTransport>();
        if (transport != null)
            transport.SetConnectionData(serverAddress, port);
    }
}
