using UnityEngine;

public static class InventoryExtensions
{
    public static bool HasItems(this PlayerInventory inventory, RecipeIngredient[] ingredients)
    {
        if (inventory == null || ingredients == null) return false;
        foreach (var ingredient in ingredients)
        {
            int total = 0;
            for (int i = 0; i < inventory.Slots.Count; i++)
            {
                var slot = inventory.Slots[i];
                if (slot.ItemId.ToString() == ingredient.itemId) total += slot.Amount;
            }
            if (total < ingredient.amount) return false;
        }
        return true;
    }

    public static void RemoveItems(this PlayerInventory inventory, RecipeIngredient[] ingredients)
    {
        if (inventory == null || ingredients == null || !inventory.IsServer) return;
        foreach (var ingredient in ingredients)
        {
            int remaining = ingredient.amount;
            for (int i = 0; i < inventory.Slots.Count && remaining > 0; i++)
            {
                var slot = inventory.Slots[i];
                if (slot.ItemId.ToString() != ingredient.itemId || slot.Amount <= 0) continue;
                int take = Mathf.Min(slot.Amount, remaining);
                slot.Amount -= take;
                remaining -= take;
                if (slot.Amount <= 0) slot = new InventorySlot("", 0);
                inventory.Slots[i] = slot;
            }
        }
    }

    public static void AddItems(this PlayerInventory inventory, string itemId, int amount)
    {
        if (inventory == null || !inventory.IsServer || string.IsNullOrEmpty(itemId) || amount <= 0) return;
        for (int i = 0; i < inventory.Slots.Count && amount > 0; i++)
        {
            var slot = inventory.Slots[i];
            if (slot.ItemId.ToString() != itemId || slot.Amount >= 100) continue;
            int add = Mathf.Min(100 - slot.Amount, amount);
            slot.Amount += add;
            amount -= add;
            inventory.Slots[i] = slot;
        }
        for (int i = 0; i < inventory.Slots.Count && amount > 0; i++)
        {
            var slot = inventory.Slots[i];
            if (slot.Amount != 0) continue;
            int add = Mathf.Min(100, amount);
            inventory.Slots[i] = new InventorySlot(itemId, add);
            amount -= add;
        }
        // TODO: обработать переполнение инвентаря через выпадение предметов.
    }
}
