using UnityEngine;

[CreateAssetMenu(menuName = "Mobile Survival/Item Definition")]
public class ItemDefinition : ScriptableObject
{
    public string itemId;
    public string displayName;
    [TextArea] public string description;
    public Sprite icon;
    [Min(1)] public int maxStack = 100;
}
