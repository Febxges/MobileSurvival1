using System;
using Unity.Collections;
using Unity.Netcode;
using UnityEngine;

[Serializable]
public struct InventorySlot : INetworkSerializable, IEquatable<InventorySlot>
{
    public FixedString64Bytes ItemId;
    public int Amount;

    public InventorySlot(string id, int amount)
    {
        ItemId = new FixedString64Bytes(id ?? "");
        Amount = amount;
    }

    public void NetworkSerialize<T>(BufferSerializer<T> serializer) where T : IReaderWriter
    {
        serializer.SerializeValue(ref ItemId);
        serializer.SerializeValue(ref Amount);
    }

    public bool Equals(InventorySlot other) => ItemId.Equals(other.ItemId) && Amount == other.Amount;
}

public class PlayerInventory : NetworkBehaviour
{
    public const int SlotCount = 24;
    public NetworkList<InventorySlot> Slots;

    private void Awake() => Slots = new NetworkList<InventorySlot>();

    public override void OnNetworkSpawn()
    {
        if (IsServer && Slots.Count == 0)
            for (int i = 0; i < SlotCount; i++) Slots.Add(new InventorySlot("", 0));
    }

    [ServerRpc]
    public void MoveSlotServerRpc(int from, int to)
    {
        if (from < 0 || from >= Slots.Count || to < 0 || to >= Slots.Count || from == to) return;
        var a = Slots[from];
        Slots[from] = Slots[to];
        Slots[to] = a;
    }

    [ServerRpc(RequireOwnership = false)]
    public void AddItemServerRpc(string itemId, int amount, ServerRpcParams rpcParams = default)
    {
        // Для production нужно валидировать источник предмета и расстояние на сервере.
        if (string.IsNullOrWhiteSpace(itemId) || itemId.Length > 64 || amount <= 0 || amount > 10000) return;
        this.AddItems(itemId, amount);
    }
}
