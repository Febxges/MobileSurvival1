using Unity.Netcode;
using UnityEngine;

public class WorldPickup : NetworkBehaviour
{
    [SerializeField] private string itemId = "wood";
    [SerializeField] private int amount = 100;
    [SerializeField] private float pickupDistance = 3f;

    [ServerRpc(RequireOwnership = false)]
    public void RequestPickupServerRpc(NetworkObjectReference playerRef, ServerRpcParams rpcParams = default)
    {
        if (!playerRef.TryGet(out NetworkObject player)) return;
        if (Vector3.Distance(transform.position, player.transform.position) > pickupDistance) return;

        var inventory = player.GetComponent<PlayerInventory>();
        if (inventory == null) return;

        inventory.AddItemServerRpc(itemId, amount);
        NetworkObject.Despawn(true);
    }
}
