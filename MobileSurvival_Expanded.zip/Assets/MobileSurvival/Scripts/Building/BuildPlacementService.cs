using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Минимальная серверная точка расширения для строительства.
/// Размещение разрешается только в пределах reachDistance от игрока.
/// </summary>
public class BuildPlacementService : NetworkBehaviour
{
    [SerializeField] private BuildPieceDefinition[] pieces;
    [SerializeField] private float reachDistance = 6f;
    [SerializeField] private LayerMask groundMask = ~0;

    [ServerRpc]
    public void PlacePieceServerRpc(string pieceId, Vector3 position, float yaw,
        ServerRpcParams rpcParams = default)
    {
        if (!IsServer || string.IsNullOrWhiteSpace(pieceId)) return;
        ulong sender = rpcParams.Receive.SenderClientId;
        if (!NetworkManager.ConnectedClients.TryGetValue(sender, out var client) ||
            client.PlayerObject == null) return;

        var player = client.PlayerObject;
        if (Vector3.Distance(player.transform.position, position) > reachDistance) return;

        BuildPieceDefinition definition = null;
        foreach (var p in pieces)
            if (p != null && p.pieceId == pieceId) { definition = p; break; }
        if (definition == null || definition.prefab == null) return;

        var inventory = player.GetComponent<PlayerInventory>();
        if (inventory == null || !inventory.HasItems(new[] {
            new RecipeIngredient { itemId = "wood", amount = definition.woodCost }
        })) return;

        // Не допускаем размещение в воздухе: луч вниз должен найти поверхность.
        if (!Physics.Raycast(position + Vector3.up * 2f, Vector3.down, out var hit, 4f, groundMask))
            return;

        inventory.RemoveItems(new[] {
            new RecipeIngredient { itemId = "wood", amount = definition.woodCost }
        });

        Vector3 finalPosition = hit.point + definition.placementOffset;
        var instance = Instantiate(definition.prefab, finalPosition, Quaternion.Euler(0f, yaw, 0f));
        var networkObject = instance.GetComponent<NetworkObject>();
        if (networkObject == null) { Destroy(instance); return; }
        networkObject.Spawn(true);
    }
}
