using UnityEngine;

[CreateAssetMenu(menuName = "Mobile Survival/Build Piece")]
public class BuildPieceDefinition : ScriptableObject
{
    public string pieceId;
    public GameObject prefab;
    [Min(0)] public int woodCost = 100;
    public Vector3 placementOffset;
}
