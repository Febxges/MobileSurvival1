using Unity.Netcode;
using UnityEngine;

public class SurvivalStats : NetworkBehaviour
{
    [SerializeField] private float maxHealth = 100f;
    [SerializeField] private float maxHunger = 100f;
    [SerializeField] private float maxThirst = 100f;
    [SerializeField] private float hungerLossPerMinute = 3f;
    [SerializeField] private float thirstLossPerMinute = 5f;

    public NetworkVariable<float> Health = new(100f);
    public NetworkVariable<float> Hunger = new(100f);
    public NetworkVariable<float> Thirst = new(100f);

    private float tick;

    public override void OnNetworkSpawn()
    {
        if (IsServer)
        {
            Health.Value = maxHealth;
            Hunger.Value = maxHunger;
            Thirst.Value = maxThirst;
        }
    }

    private void Update()
    {
        if (!IsServer || !IsSpawned) return;
        tick += Time.deltaTime;
        if (tick < 1f) return;
        tick = 0f;

        Hunger.Value = Mathf.Max(0, Hunger.Value - hungerLossPerMinute / 60f);
        Thirst.Value = Mathf.Max(0, Thirst.Value - thirstLossPerMinute / 60f);

        if (Hunger.Value <= 0 || Thirst.Value <= 0)
            Health.Value = Mathf.Max(0, Health.Value - 1f);
    }

    [ServerRpc(RequireOwnership = false)]
    public void RequestConsumeServerRpc(float hunger, float thirst)
    {
        Hunger.Value = Mathf.Clamp(Hunger.Value + hunger, 0, maxHunger);
        Thirst.Value = Mathf.Clamp(Thirst.Value + thirst, 0, maxThirst);
    }
}
