using Unity.Netcode;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerMotor : NetworkBehaviour
{
    [Header("References")]
    [SerializeField] private MobileInput input;
    [SerializeField] private Transform cameraPivot;
    [Header("Movement")]
    [SerializeField] private float walkSpeed = 4.2f;
    [SerializeField] private float sprintSpeed = 6.0f;
    [SerializeField] private float crouchSpeed = 2.0f;
    [SerializeField] private float jumpHeight = 1.15f;
    [SerializeField] private float gravity = -22f;
    [SerializeField] private float lookSensitivity = 0.12f;
    [SerializeField] private float maxLookAngle = 85f;

    private CharacterController controller;
    private float verticalVelocity;
    private float pitch;

    private void Awake() => controller = GetComponent<CharacterController>();

    public override void OnNetworkSpawn()
    {
        if (cameraPivot != null) cameraPivot.gameObject.SetActive(IsOwner);
        if (input != null) input.enabled = IsOwner;
        enabled = IsOwner;
    }

    private void Update()
    {
        if (!IsOwner || input == null) return;

        Vector2 move = input.Move;
        Vector3 direction = transform.right * move.x + transform.forward * move.y;
        float speed = input.CrouchHeld ? crouchSpeed : (input.SprintHeld ? sprintSpeed : walkSpeed);

        if (controller.isGrounded && verticalVelocity < 0f) verticalVelocity = -2f;
        if (controller.isGrounded && input.ConsumeJump())
            verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);

        verticalVelocity += gravity * Time.deltaTime;
        controller.Move((direction * speed + Vector3.up * verticalVelocity) * Time.deltaTime);

        Vector2 look = input.Look;
        transform.Rotate(Vector3.up * (look.x * lookSensitivity));
        pitch = Mathf.Clamp(pitch - look.y * lookSensitivity, -maxLookAngle, maxLookAngle);
        if (cameraPivot != null) cameraPivot.localRotation = Quaternion.Euler(pitch, 0f, 0f);
        input.ClearLook();
    }
}
