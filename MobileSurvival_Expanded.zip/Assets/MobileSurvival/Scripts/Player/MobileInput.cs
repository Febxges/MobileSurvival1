using UnityEngine;

/// <summary>
/// Общий ввод для клавиатуры и мобильного UI.
/// UI может вызывать SetMove, SetLook, SetJump, SetSprint, SetCrouch.
/// </summary>
public class MobileInput : MonoBehaviour
{
    public Vector2 Move { get; private set; }
    public Vector2 Look { get; private set; }
    public bool JumpPressed { get; private set; }
    public bool SprintHeld { get; private set; }
    public bool CrouchHeld { get; private set; }

    [SerializeField] private bool enableKeyboardInEditor = true;

    public void SetMove(Vector2 value) => Move = Vector2.ClampMagnitude(value, 1f);
    public void SetLook(Vector2 delta) => Look = delta;
    public void SetJump() => JumpPressed = true;
    public void SetSprint(bool value) => SprintHeld = value;
    public void SetCrouch(bool value) => CrouchHeld = value;

    public void ClearLook() => Look = Vector2.zero;

    private void Update()
    {
        if (!enableKeyboardInEditor || Application.isMobilePlatform) return;

        Vector2 keyboard = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        if (keyboard.sqrMagnitude > 0.01f) Move = Vector2.ClampMagnitude(keyboard, 1f);

        if (Input.GetKeyDown(KeyCode.Space)) JumpPressed = true;
        SprintHeld = Input.GetKey(KeyCode.LeftShift);
        CrouchHeld = Input.GetKey(KeyCode.LeftControl);
        Look = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));
    }

    public bool ConsumeJump()
    {
        bool value = JumpPressed;
        JumpPressed = false;
        return value;
    }
}
