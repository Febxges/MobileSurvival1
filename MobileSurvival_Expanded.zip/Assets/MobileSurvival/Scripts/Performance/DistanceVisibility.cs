using UnityEngine;

/// <summary>Простое отключение визуала вдали. Не используйте на сетевых корневых объектах.</summary>
public class DistanceVisibility : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private float visibleDistance = 90f;
    [SerializeField] private Renderer[] renderers;
    private bool visible = true;

    private void Start()
    {
        if (renderers == null || renderers.Length == 0)
            renderers = GetComponentsInChildren<Renderer>(true);
    }

    private void Update()
    {
        if (target == null) return;
        bool shouldBeVisible = (target.position - transform.position).sqrMagnitude
                               <= visibleDistance * visibleDistance;
        if (visible == shouldBeVisible) return;
        visible = shouldBeVisible;
        foreach (var r in renderers) if (r != null) r.enabled = visible;
    }

    public void SetTarget(Transform value) => target = value;
}
