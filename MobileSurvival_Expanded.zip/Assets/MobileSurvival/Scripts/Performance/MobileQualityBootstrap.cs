using UnityEngine;

public class MobileQualityBootstrap : MonoBehaviour
{
    [SerializeField] private int targetFrameRate = 30;
    [SerializeField] private int mobileQualityLevel = 0;

    private void Awake()
    {
        Application.targetFrameRate = targetFrameRate;
        QualitySettings.vSyncCount = 0;
        QualitySettings.SetQualityLevel(mobileQualityLevel, true);
        QualitySettings.shadows = ShadowQuality.Disable;
        QualitySettings.antiAliasing = 0;
        QualitySettings.anisotropicFiltering = AnisotropicFiltering.Disable;
    }
}
