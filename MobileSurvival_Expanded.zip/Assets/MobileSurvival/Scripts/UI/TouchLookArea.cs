using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>Повесьте на прозрачную UI-панель правой части экрана.</summary>
public class TouchLookArea : MonoBehaviour, IDragHandler
{
    [SerializeField] private MobileInput target;
    [SerializeField] private float sensitivity = 1f;

    public void OnDrag(PointerEventData eventData)
    {
        if (target != null) target.SetLook(eventData.delta * sensitivity);
    }
}
