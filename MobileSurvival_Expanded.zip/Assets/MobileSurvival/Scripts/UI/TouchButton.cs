using UnityEngine;
using UnityEngine.EventSystems;

public class TouchButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public enum ActionType { Jump, Sprint, Crouch }
    [SerializeField] private MobileInput target;
    [SerializeField] private ActionType action;

    public void OnPointerDown(PointerEventData eventData)
    {
        if (target == null) return;
        if (action == ActionType.Jump) target.SetJump();
        if (action == ActionType.Sprint) target.SetSprint(true);
        if (action == ActionType.Crouch) target.SetCrouch(true);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (target == null) return;
        if (action == ActionType.Sprint) target.SetSprint(false);
        if (action == ActionType.Crouch) target.SetCrouch(false);
    }
}
